import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import ShopDashboard from "./shop-dashboard";

export default async function DashboardPage() {
  const supabase = await createClient();
  const {data:{user}} = await supabase.auth.getUser();
  if (!user) redirect("/auth");
  const {data:shops} = await supabase.from("shops").select("*").eq("owner_id",user.id).order("created_at",{ascending:false});
  return <main className="container py-8"><Link href="/" className="text-emerald-700 font-bold">← APNA RATE</Link><div className="mt-5"><h1 className="text-3xl font-black">Shopkeeper dashboard</h1><p className="muted text-sm mt-1">Signed in as {user.email}</p></div><ShopDashboard shops={shops||[]}/></main>;
}
