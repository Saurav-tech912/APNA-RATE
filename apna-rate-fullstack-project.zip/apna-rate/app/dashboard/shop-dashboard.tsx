"use client";
import { FormEvent, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Shop={id:string;name:string;city:string;area:string;status:string};
export default function ShopDashboard({shops:initial}:{shops:Shop[]}) {
 const [shops,setShops]=useState(initial),[message,setMessage]=useState("");
 const [busy,setBusy]=useState(false);
 async function register(e:FormEvent<HTMLFormElement>){
  e.preventDefault();setBusy(true);setMessage("");
  const form=new FormData(e.currentTarget);const payload=Object.fromEntries(form.entries());
  const res=await fetch("/api/shops",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
  const json=await res.json();if(!res.ok)setMessage(json.error||"Could not register shop.");else{setShops([json.shop,...shops]);(e.target as HTMLFormElement).reset();setMessage("Shop submitted. It will appear publicly after admin verification.");}
  setBusy(false);
 }
 async function addListing(e:FormEvent<HTMLFormElement>){
  e.preventDefault();setBusy(true);setMessage("");
  const f=new FormData(e.currentTarget);const payload={shop_id:f.get("shop_id"),name:f.get("name"),category:f.get("category"),brand:f.get("brand")||null,unit:f.get("unit"),price:Number(f.get("price")),stock:f.get("stock")};
  const res=await fetch("/api/listings",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
  const json=await res.json();setMessage(res.ok?"Product price saved.":json.error||"Could not save listing.");setBusy(false);
 }
 async function logout(){const supabase=createClient();await supabase.auth.signOut();location.href="/";}
 return <div className="grid lg:grid-cols-2 gap-5 mt-6">
  <section className="card p-5"><h2 className="font-bold text-xl">Register a shop</h2><form onSubmit={register} className="space-y-3 mt-4">
   {["name","phone","address","area","city","state","pincode"].map((x)=><label className="block text-sm capitalize" key={x}>{x}<input className="field mt-1" name={x} required placeholder={x==="pincode"?"6-digit PIN code":""}/></label>)}
   <button disabled={busy} className="btn btn-primary w-full">Submit shop for verification</button>
  </form></section>
  <section className="space-y-4"><div className="card p-5"><h2 className="font-bold text-xl">Your shops</h2>{shops.length?shops.map(s=><div key={s.id} className="border-t py-3 mt-3"><b>{s.name}</b><p className="muted text-xs">{s.area}, {s.city} · Status: {s.status}</p></div>):<p className="muted text-sm mt-3">No shops registered yet.</p>}</div>
  <div className="card p-5"><h2 className="font-bold text-xl">Add / update a product</h2><form onSubmit={addListing} className="space-y-3 mt-4">
   <label className="block text-sm">Shop<select className="field mt-1" name="shop_id" required>{shops.map(s=><option key={s.id} value={s.id}>{s.name} ({s.status})</option>)}</select></label>
   <label className="block text-sm">Product<input className="field mt-1" name="name" required minLength={2}/></label>
   <label className="block text-sm">Category<select className="field mt-1" name="category"><option>Grocery</option><option>Vegetables</option><option>Electronics</option><option>Clothes</option><option>Medical</option><option>Other</option></select></label>
   <label className="block text-sm">Brand (optional)<input className="field mt-1" name="brand"/></label>
   <label className="block text-sm">Unit<input className="field mt-1" name="unit" placeholder="1 kg / 1 litre / piece" required/></label>
   <label className="block text-sm">Price ₹<input className="field mt-1" name="price" type="number" min="0.01" step="0.01" required/></label>
   <label className="block text-sm">Stock<select className="field mt-1" name="stock"><option value="available">Available</option><option value="limited">Limited</option><option value="out_of_stock">Out of stock</option></select></label>
   <button disabled={busy||shops.length===0} className="btn btn-primary w-full">Save listing</button>
  </form></div>
  {message&&<p className="p-3 rounded-xl bg-emerald-50 text-emerald-800 text-sm">{message}</p>}<button onClick={logout} className="btn btn-outline">Sign out</button></section>
 </div>;
}
