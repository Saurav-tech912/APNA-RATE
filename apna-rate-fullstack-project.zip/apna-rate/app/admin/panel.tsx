"use client";
import { useState } from "react";
type Shop={id:string;name:string;city:string;area:string;status:string};
type Listing={id:string;price:number;stock:string;is_active:boolean;products:any;shops:any};
export default function AdminPanel({shops:initial,listings}:{shops:Shop[];listings:Listing[]}){
 const [shops,setShops]=useState(initial),[message,setMessage]=useState("");
 async function update(id:string,status:"verified"|"rejected"|"suspended"){
  const res=await fetch(`/api/admin/shops/${id}`,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({status})});
  const data=await res.json();if(!res.ok){setMessage(data.error||"Update failed");return}
  setShops(shops.map(s=>s.id===id?{...s,status}:s));setMessage("Shop status updated.");
 }
 return <div className="space-y-5 mt-6"><div className="card p-5"><h2 className="font-bold text-xl">Shop verification ({shops.length})</h2>{shops.map(s=><div key={s.id} className="border-t py-3 mt-3 flex flex-wrap items-center justify-between gap-2"><div><b>{s.name}</b><p className="muted text-xs">{s.area}, {s.city} · {s.status}</p></div><div className="flex gap-2"><button className="btn btn-primary" onClick={()=>update(s.id,"verified")}>Approve</button><button className="btn btn-outline" onClick={()=>update(s.id,"rejected")}>Reject</button></div></div>)}</div>
 <div className="card p-5"><h2 className="font-bold text-xl">Recent listings ({listings.length})</h2>{listings.map(l=><div key={l.id} className="border-t py-3 mt-2 flex justify-between gap-2 text-sm"><span>{l.products?.name} · {l.shops?.name}</span><b>₹{l.price}</b></div>)}</div>{message&&<p className="text-sm text-emerald-700">{message}</p>}</div>;
}
