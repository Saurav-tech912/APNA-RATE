import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import AdminPanel from "./panel";

export default async function AdminPage(){
 const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();
 if(!user)redirect("/auth");
 const {data:profile}=await supabase.from("profiles").select("role").eq("id",user.id).single();
 if(profile?.role!=="admin")return <main className="container py-12"><Link href="/" className="text-emerald-700">← Home</Link><div className="card p-6 mt-5">Admin access is restricted. Ask the project owner to grant your account the admin role.</div></main>;
 const {data:shops}=await supabase.from("shops").select("*").order("created_at",{ascending:false});
 const {data:listings}=await supabase.from("listings").select("id,price,stock,is_active,products(name),shops(name,city)").order("updated_at",{ascending:false}).limit(100);
 return <main className="container py-8"><Link href="/" className="text-emerald-700">← Home</Link><h1 className="text-3xl font-black mt-4">Admin moderation</h1><AdminPanel shops={shops||[]} listings={listings||[]}/></main>;
}
