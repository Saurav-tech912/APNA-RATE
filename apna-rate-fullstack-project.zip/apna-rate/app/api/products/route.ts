import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { z } from "zod";

const querySchema=z.object({city:z.string().min(2).max(100),area:z.string().max(100).optional(),q:z.string().max(160).optional(),category:z.string().max(60).optional(),pincode:z.string().regex(/^[1-9][0-9]{5}$/).optional()});
export async function GET(request:Request){
 const params=Object.fromEntries(new URL(request.url).searchParams.entries());
 const parsed=querySchema.safeParse(params);
 if(!parsed.success)return NextResponse.json({error:"Provide a valid city and optional area, PIN, query or category."},{status:400});
 const v=parsed.data;const supabase=await createClient();
 const {data,error}=await supabase.rpc("search_local_products",{p_city:v.city,p_area:v.area||null,p_query:v.q||null,p_category:v.category||null,p_pincode:v.pincode||null});
 if(error)return NextResponse.json({error:"Search unavailable. Check database setup."},{status:500});
 return NextResponse.json({items:data||[]});
}
