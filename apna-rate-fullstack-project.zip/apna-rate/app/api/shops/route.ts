import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { shopSchema } from "@/lib/validators";

export async function POST(request: Request) {
  const supabase = await createClient();
  const {data:{user}} = await supabase.auth.getUser();
  if (!user) return NextResponse.json({error:"Please log in first."},{status:401});
  const parsed = shopSchema.safeParse(await request.json().catch(()=>null));
  if (!parsed.success) return NextResponse.json({error:"Invalid shop details.",details:parsed.error.flatten()},{status:400});
  const {data:shop,error} = await supabase.from("shops").insert({...parsed.data,owner_id:user.id}).select().single();
  if(error) return NextResponse.json({error:error.message},{status:400});
  return NextResponse.json({shop},{status:201});
}
