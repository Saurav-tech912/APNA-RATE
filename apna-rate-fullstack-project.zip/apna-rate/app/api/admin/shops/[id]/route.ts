import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { z } from "zod";

const schema=z.object({status:z.enum(["verified","rejected","suspended"])});
export async function PATCH(request:Request,{params}:{params:{id:string}}){
 const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();
 if(!user)return NextResponse.json({error:"Unauthorized"},{status:401});
 const {data:profile}=await supabase.from("profiles").select("role").eq("id",user.id).single();
 if(profile?.role!=="admin")return NextResponse.json({error:"Admin only"},{status:403});
 const parsed=schema.safeParse(await request.json().catch(()=>null));
 if(!parsed.success)return NextResponse.json({error:"Invalid status"},{status:400});
 const {data,error}=await supabase.from("shops").update({status:parsed.data.status}).eq("id",params.id).select().single();
 if(error)return NextResponse.json({error:error.message},{status:400});
 return NextResponse.json({shop:data});
}
