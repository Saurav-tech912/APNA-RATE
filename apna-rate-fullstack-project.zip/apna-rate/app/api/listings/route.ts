import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { listingSchema } from "@/lib/validators";

export async function POST(request: Request) {
  const supabase = await createClient();
  const {data:{user}} = await supabase.auth.getUser();
  if (!user) return NextResponse.json({error:"Please log in first."},{status:401});
  const parsed = listingSchema.safeParse(await request.json().catch(()=>null));
  if (!parsed.success) return NextResponse.json({error:"Invalid product listing.",details:parsed.error.flatten()},{status:400});
  const v = parsed.data;
  const {data:shop,error:shopError} = await supabase.from("shops").select("id,status").eq("id",v.shop_id).eq("owner_id",user.id).single();
  if(shopError || !shop) return NextResponse.json({error:"Shop not found or not owned by this account."},{status:403});
  if(shop.status !== "verified") return NextResponse.json({error:"Your shop must be verified before publishing public prices."},{status:403});
  let productQuery = supabase.from("products").select("id").eq("name",v.name).eq("unit",v.unit);
  productQuery = v.brand ? productQuery.eq("brand",v.brand) : productQuery.is("brand",null);
  const {data:existingProduct} = await productQuery.maybeSingle();
  let productId = existingProduct?.id;
  if (!productId) {
    const {data:createdProduct,error:productError} = await supabase.from("products").insert({name:v.name,category:v.category,brand:v.brand,unit:v.unit}).select("id").single();
    if(productError) return NextResponse.json({error:productError.message},{status:400});
    productId = createdProduct.id;
  }
  const {data:listing,error} = await supabase.from("listings").upsert({shop_id:v.shop_id,product_id:productId,price:v.price,stock:v.stock,is_active:true},{onConflict:"shop_id,product_id"}).select().single();
  if(error) return NextResponse.json({error:error.message},{status:400});
  return NextResponse.json({listing},{status:201});
}
