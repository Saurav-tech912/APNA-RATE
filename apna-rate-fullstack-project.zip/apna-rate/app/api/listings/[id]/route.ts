import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { z } from "zod";

const schema = z.object({price:z.number().positive().optional(),stock:z.enum(["available","limited","out_of_stock"]).optional(),is_active:z.boolean().optional()}).refine(v=>Object.keys(v).length>0);
export async function PATCH(request:Request,{params}:{params:{id:string}}){
 const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();
 if(!user)return NextResponse.json({error:"Unauthorized"},{status:401});
 const parsed=schema.safeParse(await request.json().catch(()=>null));
 if(!parsed.success)return NextResponse.json({error:"Invalid update"},{status:400});
 const {data,error}=await supabase.from("listings").update(parsed.data).eq("id",params.id).select().single();
 if(error)return NextResponse.json({error:error.message},{status:403});
 return NextResponse.json({listing:data});
}
