import Link from "next/link";
import { Search, Store, MapPin, ShieldCheck, ArrowRight, Languages } from "lucide-react";
import { createClient } from "@/lib/supabase/server";

type Item = {
  listing_id: string; product_id: string; product_name: string; category: string;
  brand: string | null; unit: string; price: number; stock: string; updated_at: string;
  shop_id: string; shop_name: string; shop_phone: string; shop_address: string;
  area: string; city: string; state: string; pincode: string;
};

export default async function Home({ searchParams }: { searchParams: { city?: string; area?: string; q?: string; category?: string; pincode?: string } }) {
  const city = searchParams.city || "Patna";
  const area = searchParams.area || "Masaurhi";
  const q = searchParams.q || "";
  const category = searchParams.category || "";
  let items: Item[] = [];
  let error = "";
  try {
    const supabase = await createClient();
    const { data, error: dbError } = await supabase.rpc("search_local_products", {
      p_city: city, p_area: area || null, p_query: q || null,
      p_category: category || null, p_pincode: searchParams.pincode || null
    });
    if (dbError) error = "Database setup is incomplete. Run supabase/schema.sql and configure environment variables.";
    else items = (data || []) as Item[];
  } catch {
    error = "Connect Supabase to show verified shop listings.";
  }

  return <main>
    <header className="bg-white border-b border-emerald-100">
      <div className="container py-4 flex items-center justify-between gap-3">
        <Link href="/" className="flex items-center gap-3">
          <span className="w-11 h-11 rounded-xl bg-emerald-700 text-white grid place-items-center text-xl font-black">₹</span>
          <span><strong className="text-xl tracking-tight">APNA RATE</strong><small className="block muted">Apne area ka sahi rate</small></span>
        </Link>
        <nav className="flex items-center gap-2 text-sm">
          <Link className="btn btn-outline" href="/auth">Login</Link>
          <Link className="btn btn-primary" href="/dashboard"><Store size={16}/> Shopkeeper</Link>
        </nav>
      </div>
    </header>

    <section className="bg-gradient-to-r from-emerald-900 to-emerald-600 text-white">
      <div className="container py-12 md:py-16">
        <span className="text-emerald-100 text-sm font-semibold">LOCAL SHOPPING · INDIA</span>
        <h1 className="text-3xl md:text-5xl font-black mt-3 max-w-2xl">Sasta saman, paas ki dukaan.</h1>
        <p className="mt-3 text-emerald-50 max-w-xl">Compare prices and check product availability at local shops before you buy.</p>
        <form className="mt-7 grid grid-cols-1 md:grid-cols-5 gap-2 bg-white p-3 rounded-2xl max-w-4xl text-slate-800">
          <label className="md:col-span-1 text-xs font-semibold">City<input name="city" defaultValue={city} className="field mt-1" placeholder="Patna"/></label>
          <label className="md:col-span-1 text-xs font-semibold">Area<input name="area" defaultValue={area} className="field mt-1" placeholder="Masaurhi"/></label>
          <label className="md:col-span-1 text-xs font-semibold">PIN code<input name="pincode" defaultValue={searchParams.pincode} className="field mt-1" placeholder="804452"/></label>
          <label className="md:col-span-1 text-xs font-semibold">Product<input name="q" defaultValue={q} className="field mt-1" placeholder="Atta, rice..."/></label>
          <button className="btn btn-primary self-end"><Search size={17}/> Search</button>
        </form>
        <p className="text-xs text-emerald-100 mt-3">Only verified shop listings are intended to appear in live search.</p>
      </div>
    </section>

    <section className="container py-9">
      <div className="flex flex-wrap items-end justify-between gap-3 mb-5">
        <div><h2 className="text-2xl font-extrabold">Prices near {area}, {city}</h2><p className="muted text-sm mt-1">Shop-wise comparison · India-wide design</p></div>
        <Link href="/dashboard" className="text-emerald-700 font-bold text-sm">List your shop <ArrowRight className="inline" size={16}/></Link>
      </div>
      {error && <div className="card p-4 mb-4 text-amber-800 bg-amber-50 text-sm">{error}</div>}
      {items.length === 0 ? <div className="card p-8 text-center">
        <div className="text-4xl mb-3">🛍️</div><h3 className="font-bold text-lg">No verified listings found</h3>
        <p className="muted text-sm mt-2">Try another area, or invite local shopkeepers to register.</p>
        <Link className="btn btn-primary mt-4" href="/dashboard">Register a shop</Link>
      </div> : <div className="grid md:grid-cols-2 gap-4">
        {items.map(item => <article key={item.listing_id} className="card p-4">
          <div className="flex justify-between gap-3"><div><span className="tag">{item.category}</span><h3 className="font-bold text-lg mt-2">{item.product_name}</h3><p className="muted text-xs">{item.brand || "Local product"} · {item.unit}</p></div><strong className="text-2xl text-emerald-700">₹{Number(item.price).toLocaleString("en-IN")}</strong></div>
          <div className="border-t mt-4 pt-3 flex items-start justify-between gap-2 text-sm"><div><b><Store className="inline mr-1" size={15}/>{item.shop_name}</b><p className="muted text-xs mt-1"><MapPin className="inline" size={12}/> {item.area}, {item.city} · {item.pincode}</p></div><span className="tag">{item.stock.replace("_"," ")}</span></div>
          <p className="muted text-xs mt-3">Updated {new Date(item.updated_at).toLocaleString("en-IN")}</p>
        </article>)}
      </div>}
    </section>

    <section className="bg-emerald-50 border-y border-emerald-100">
      <div className="container py-9 grid md:grid-cols-3 gap-5">
        <div><Search className="text-emerald-700 mb-2"/><b>Search nearby</b><p className="muted text-sm mt-1">Find products by city, area and PIN code.</p></div>
        <div><ShieldCheck className="text-emerald-700 mb-2"/><b>Verified shops</b><p className="muted text-sm mt-1">Shop listings are moderated before appearing publicly.</p></div>
        <div><Languages className="text-emerald-700 mb-2"/><b>Hindi + English</b><p className="muted text-sm mt-1">A bilingual experience is planned across customer and seller flows.</p></div>
      </div>
    </section>
    <footer className="container py-7 text-xs muted flex flex-wrap justify-between gap-3"><span>© {new Date().getFullYear()} APNA RATE</span><span>Prices and stock can change. Confirm with shop before visiting.</span><Link href="/admin">Admin</Link></footer>
  </main>;
}
