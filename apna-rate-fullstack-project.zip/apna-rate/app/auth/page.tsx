"use client";
import { FormEvent, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";

export default function AuthPage() {
  const [mode,setMode] = useState<"signup"|"login">("signup");
  const [message,setMessage] = useState("");
  const [busy,setBusy] = useState(false);
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setMessage("");
    const data = new FormData(e.currentTarget);
    const email = String(data.get("email")); const password = String(data.get("password"));
    const name = String(data.get("name") || "");
    try {
      const supabase = createClient();
      const result = mode === "signup"
        ? await supabase.auth.signUp({ email,password,options:{data:{full_name:name},emailRedirectTo:`${location.origin}/auth/callback`} })
        : await supabase.auth.signInWithPassword({email,password});
      if(result.error) setMessage(result.error.message);
      else setMessage(mode==="signup"?"Account created. Check your email to confirm, then log in.":"Login successful. Open your dashboard.");
    } catch { setMessage("Set Supabase URL and anon key in .env.local first."); }
    setBusy(false);
  }
  return <main className="container py-12 max-w-md"><Link href="/" className="text-emerald-700 font-bold">← APNA RATE</Link><div className="card p-6 mt-5">
    <h1 className="text-2xl font-black">{mode==="signup"?"Create account":"Welcome back"}</h1><p className="muted text-sm mt-1">Customer and shopkeeper access</p>
    <form onSubmit={submit} className="space-y-3 mt-6">
      {mode==="signup"&&<label className="block text-sm">Full name<input name="name" className="field mt-1" required/></label>}
      <label className="block text-sm">Email<input name="email" type="email" className="field mt-1" required/></label>
      <label className="block text-sm">Password<input name="password" type="password" minLength={8} className="field mt-1" required/></label>
      <button disabled={busy} className="btn btn-primary w-full">{busy?"Please wait…":mode==="signup"?"Create account":"Login"}</button>
    </form>
    {message&&<p className="text-sm mt-4 p-3 rounded-lg bg-emerald-50 text-emerald-800">{message}</p>}
    <button className="text-sm text-emerald-700 font-bold mt-4" onClick={()=>setMode(mode==="signup"?"login":"signup")}>{mode==="signup"?"Already registered? Login":"New user? Create account"}</button>
  </div></main>;
}
