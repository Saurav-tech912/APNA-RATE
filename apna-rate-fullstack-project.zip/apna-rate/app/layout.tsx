import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "APNA RATE — Compare local shop prices",
  description: "Compare prices and availability at nearby local shops across India."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
