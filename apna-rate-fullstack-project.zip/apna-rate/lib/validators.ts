import { z } from "zod";

export const shopSchema = z.object({
  name: z.string().trim().min(2).max(120),
  phone: z.string().trim().regex(/^[0-9+\-\s]{10,16}$/),
  address: z.string().trim().min(5).max(250),
  area: z.string().trim().min(2).max(100),
  city: z.string().trim().min(2).max(100),
  state: z.string().trim().min(2).max(100),
  pincode: z.string().regex(/^[1-9][0-9]{5}$/)
});

export const listingSchema = z.object({
  shop_id: z.string().uuid(),
  name: z.string().trim().min(2).max(160),
  category: z.string().trim().min(2).max(60),
  brand: z.string().trim().max(100).optional().nullable(),
  unit: z.string().trim().min(1).max(30),
  price: z.number().positive().max(100000000),
  stock: z.enum(["available", "limited", "out_of_stock"])
});
