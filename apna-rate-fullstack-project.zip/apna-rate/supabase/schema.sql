create extension if not exists pgcrypto;

create type public.app_role as enum ('customer', 'shopkeeper', 'admin');
create type public.shop_status as enum ('pending', 'verified', 'rejected', 'suspended');
create type public.stock_status as enum ('available', 'limited', 'out_of_stock');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  role public.app_role not null default 'customer',
  preferred_language text not null default 'en' check (preferred_language in ('en','hi')),
  created_at timestamptz not null default now()
);

create table public.shops (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 2 and 120),
  phone text not null,
  address text not null,
  area text not null,
  city text not null,
  state text not null,
  pincode text not null check (pincode ~ '^[1-9][0-9]{5}$'),
  status public.shop_status not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null,
  brand text,
  unit text not null default 'piece',
  created_at timestamptz not null default now(),
  unique (name, brand, unit)
);

create table public.listings (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.shops(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  price numeric(12,2) not null check (price > 0),
  stock public.stock_status not null default 'available',
  is_active boolean not null default true,
  updated_at timestamptz not null default now(),
  unique(shop_id, product_id)
);

create index shops_location_idx on public.shops (state, city, area, pincode);
create index shops_status_idx on public.shops (status);
create index listings_product_idx on public.listings (product_id, is_active, price);
create index products_search_idx on public.products using gin (to_tsvector('simple', name || ' ' || coalesce(brand,'')));

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, full_name, phone)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), new.phone)
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.set_shopkeeper_role()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  update public.profiles set role = 'shopkeeper' where id = new.owner_id and role = 'customer';
  return new;
end;
$$;
create trigger on_shop_created
after insert on public.shops
for each row execute procedure public.set_shopkeeper_role();

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;
create trigger shops_touch before update on public.shops
for each row execute procedure public.touch_updated_at();
create trigger listings_touch before update on public.listings
for each row execute procedure public.touch_updated_at();

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

alter table public.profiles enable row level security;
alter table public.shops enable row level security;
alter table public.products enable row level security;
alter table public.listings enable row level security;

create policy "profiles read own or admin" on public.profiles
for select using (id = auth.uid() or public.is_admin());
create policy "profiles update own" on public.profiles
for update using (id = auth.uid()) with check (id = auth.uid());

-- Prevent users from promoting themselves to admin or changing their own role.
create or replace function public.protect_profile_role()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and new.role <> old.role then
    raise exception 'Profile role changes require an administrator';
  end if;
  return new;
end;
$$;
create trigger profiles_protect_role before update on public.profiles
for each row execute procedure public.protect_profile_role();
create policy "shops public verified only" on public.shops
for select using (status = 'verified' or owner_id = auth.uid() or public.is_admin());
create policy "owner create shop" on public.shops
for insert with check (owner_id = auth.uid());
create policy "owner update pending shop or admin" on public.shops
for update using ((owner_id = auth.uid() and status in ('pending','rejected')) or public.is_admin())
with check (owner_id = auth.uid() or public.is_admin());
create policy "products public read" on public.products for select using (true);
create policy "authenticated users can add catalog products" on public.products
for insert with check (auth.uid() is not null);
create policy "products admin update delete" on public.products
for update using (public.is_admin()) with check (public.is_admin());
create policy "products admin delete" on public.products
for delete using (public.is_admin());
create policy "active listings public read for verified shops" on public.listings
for select using (
  is_active and exists (select 1 from public.shops s where s.id = shop_id and s.status = 'verified')
  or exists (select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid())
  or public.is_admin()
);
create policy "shop owner insert listings" on public.listings
for insert with check (exists (select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid() and s.status = 'verified'));
create policy "shop owner update listings" on public.listings
for update using (exists (select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid()) or public.is_admin())
with check (exists (select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid()) or public.is_admin());

-- Public product search returns only active listings from verified shops.
create or replace function public.search_local_products(
  p_city text,
  p_area text default null,
  p_query text default null,
  p_category text default null,
  p_pincode text default null
)
returns table (
  listing_id uuid, product_id uuid, product_name text, category text, brand text,
  unit text, price numeric, stock public.stock_status, updated_at timestamptz,
  shop_id uuid, shop_name text, shop_phone text, shop_address text,
  area text, city text, state text, pincode text
)
language sql stable security invoker set search_path = public as $$
  select l.id, p.id, p.name, p.category, p.brand, p.unit, l.price, l.stock,
         l.updated_at, s.id, s.name, s.phone, s.address, s.area, s.city, s.state, s.pincode
  from public.listings l
  join public.products p on p.id = l.product_id
  join public.shops s on s.id = l.shop_id
  where l.is_active = true and s.status = 'verified'
    and lower(s.city) = lower(p_city)
    and (p_area is null or lower(s.area) like '%' || lower(p_area) || '%')
    and (p_pincode is null or s.pincode = p_pincode)
    and (p_query is null or p.name ilike '%' || p_query || '%' or coalesce(p.brand,'') ilike '%' || p_query || '%')
    and (p_category is null or p.category = p_category)
  order by l.price asc;
$$;

-- Optional demo seed data. Marked as non-real sample data; remove before production.
insert into public.products (name, category, brand, unit) values
('Wheat Flour 5 kg','Grocery','Sample Brand','bag'),
('Sunflower Oil 1 L','Grocery','Sample Brand','bottle'),
('Rice 5 kg','Grocery','Local Brand','bag'),
('Tomato 1 kg','Vegetables',null,'kg')
on conflict do nothing;
