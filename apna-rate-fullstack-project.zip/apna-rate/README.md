# APNA RATE — Full-stack starter

An India-wide local-shopping price comparison app. Customers search products by city/area/PIN code and compare nearby shop prices. Shopkeepers register shops and manage inventory. Admins verify shops and moderate listings.

## Stack
- Next.js 14 (App Router), React, TypeScript
- Supabase PostgreSQL + Auth + Row Level Security
- Responsive Hindi/English-ready UI
- Deployable to Vercel

## Important status
This repository is a deployable **starter implementation**, not a live service. It contains no real shop network or verified market prices. Do not advertise demo/seed prices as live prices. A real launch requires a Supabase project, environment variables, production testing, shop onboarding, moderation, privacy policy, and support operations.

## 1. Requirements
- Node.js 20+
- Supabase account and project
- Vercel account (for hosted web deployment)

## 2. Database setup
1. Create a Supabase project.
2. Open SQL Editor.
3. Run `supabase/schema.sql` in full.
4. In Authentication → URL Configuration, set your production Site URL and add:
   - `http://localhost:3000/auth/callback`
   - `https://YOUR-VERCEL-DOMAIN/auth/callback`
5. Configure email auth. For production India OTP, configure an SMS provider in Supabase Auth and test delivery, rate limits and templates.

## 3. Run locally
```bash
cp .env.example .env.local
# Fill NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY
npm install
npm run dev
```
Open http://localhost:3000.

## 4. Create an admin
Sign up normally, then use Supabase SQL Editor to promote your user:
```sql
update public.profiles
set role = 'admin'
where id = 'YOUR_AUTH_USER_UUID';
```
Never expose the Supabase service-role key in browser code. Admin authorization is checked server-side and by database RLS.

## 5. Deploy to Vercel
1. Push this folder to a private GitHub repository.
2. Import the repository in Vercel.
3. Add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` in Vercel Project → Settings → Environment Variables.
4. Deploy.
5. Add the deployed URL and `/auth/callback` to Supabase Auth URL configuration.
6. Test signup, login, shop registration, listing creation, public search and admin moderation.

## 6. Product and shop workflow
- Public users can search active listings; only verified shops are returned.
- A signed-in user can register a shop. New shops start as `pending`.
- Shop owners can add/update their own listings.
- Admins approve shops and can deactivate listings.
- Price records include `updated_at`; UI shows last updated time.

## 7. Before public launch
- Add SMS OTP provider and abuse protections.
- Add CAPTCHA / rate limiting at the edge for public auth and listing endpoints.
- Add image upload moderation, product catalog normalization and duplicate detection.
- Add PIN-code/geo-radius search using PostGIS if distance sorting is required.
- Add monitoring, backups, legal pages, privacy/consent, grievance contact and deletion workflows.
- Verify local shop prices and stock; listings can become stale.
- Run security review and load tests. Do not treat this starter as audited.

## API routes
- `GET /api/products?city=Patna&area=Masaurhi&q=atta&category=Grocery`
- `POST /api/shops` (authenticated shopkeeper)
- `POST /api/listings` (authenticated shop owner)
- `PATCH /api/listings/:id` (owner/admin)
- `PATCH /api/admin/shops/:id` (admin; approve/reject)

## Roles
`customer`, `shopkeeper`, `admin`. Users start as customer. Shop registration requires authentication; shop status is pending until an admin verifies it.
